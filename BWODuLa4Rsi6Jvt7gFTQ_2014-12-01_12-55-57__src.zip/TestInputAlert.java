import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class TestInputAlert {

	/**
	 * @param args
	 */
	public static void main(String[] args) {


		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.webstreaksprojects.com/way2automation/jquery/version5/alert/input-alert.html");
		
		driver.findElement(By.xpath("html/body/button")).click();
		
		Alert alert = driver.switchTo().alert();
		
		alert.sendKeys("Raman");
		alert.dismiss();
		
	

	}

}
