import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class TestAuthenticateCredentials {

	
	public static void main(String[] args) {


		

		WebDriver driver = new FirefoxDriver();
		driver.get("http://grcdev:nearlythere@getproactiv-ca.stg01.grdev.com/");
	

	}

}
